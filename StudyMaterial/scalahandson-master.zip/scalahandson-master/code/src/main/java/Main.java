/**
 * Created by jatin on 23/12/16.
 */
public class Main {
    public static void main(String[] args) {
        String[] arr = new String[]{"hi","hello","name"};
        Object[] arr2 = arr;
        arr2[1] = 1;


        String s = arr[1];

    }
}
