object Practice{
  def main(args: Array[String]): Unit = {
    println("hi")
  }
}